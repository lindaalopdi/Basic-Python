#Función tradicional
def fPares(limit):
	num = 1
	myList = []
	for i in range(limit):
		myList.append(i*2)
		num+=1

	return myList

#Generador
def gPares(limit):
	num = 1
	for i in range(limit):
		yield i*2
	num+=1

returnPares = gPares(10)
'''
for i in returnPares:
	print(i)
'''

print(next(returnPares))
print("Más código: ")
print(next(returnPares))
print(fPares(10))