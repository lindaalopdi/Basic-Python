def returnCities(*cities):
	for element in cities:
		# for sub_element in element:
			#yield sub_element
		yield from element
		

def main():
	cities = returnCities("Madrid", "Barcelona", "Valencia", "Bilbao")
	
	print(next(cities))
	


main()