import random

greetings = ['Hello', 'Hi','Welcome','Howdy','Salut','Bounjur','Hola']
colors = ['Red', 'Black', 'Green']
new_list = []


def rand_function():
	x = random.randint(1,6) #It works with a range of [0,9] integers
	y = random.uniform(2.5,10) #Decimals
	z = random.random() #Any random number in the range of [0,1]


	return x+y+z

def random_hi():
	value = random.choice(greetings) #It choices an element from a tuple
	print(value + ', have a nice day! ')

def random_choice():
	result = random.choices(colors, weights=[3,5,2], k=5) #Choic but with more elements
	new_list.append(result)
	print(result)
	print(new_list)

def another_random_fuctions():
	deck = list(range(1,27+1))

	new_deck = random.sample(deck, k=5)
	random.shuffle(deck)

	print(deck)
	print(new_deck)


print(rand_function())
random_hi()
random_choice()
another_random_fuctions()


